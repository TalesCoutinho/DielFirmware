import coverage
coverage.process_startup()

# This file exists to perform arbitrary site-specific customizations.
# This script is executed before every Python process to start coverage measurement.
